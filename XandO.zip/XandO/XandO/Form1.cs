using System.Runtime.Intrinsics.X86;

namespace XandO
{
    public partial class Form1 : Form
    {
        // Coustmistion dataType
        public enum Player
        {

            X, O
        }

        //data type
        Player currentPlayer;
        // make it reandomly
        Random rand = new Random();

        //count how many the player and computer was win
        int playerWinC = 0;
        int computerWinC = 0;

        List<Button> bouttons; // to make it puplic and use it any time 

        public Form1()
        {
            InitializeComponent();
            RestartGame();

        }

        private void CPUmove(object sender, EventArgs e)
        {
            // if to make sure not of button exisest
            if (bouttons.Count > 0)
            {
                //bouttons = new List<Button>();
                int index = rand.Next(bouttons.Count); // only use the button not use befor and it's randomly
                bouttons[index].Enabled = false; // stord by index
                currentPlayer = Player.O; // the computer will be O 
                bouttons[index].Text = currentPlayer.ToString(); // What we stord convert it to string 


                bouttons[index].BackColor = Color.DarkMagenta; // set the color when we use it
                bouttons.RemoveAt(index); // change the color and remove it from the list 
                CheckGame(); // call the function checkgame
                Timer.Stop(); //The end of time.

            }

        }

        private void PlayerClickButton(object sender, EventArgs e)
        {   
            //To know any input or button was click
            var button = (Button)sender;

            currentPlayer = Player.X; //you will be player x
            button.Text = currentPlayer.ToString(); // here to convert the x information to string
            button.Enabled = false;                //don't click the button two time 
            button.BackColor = Color.Gray;
            bouttons.Remove(button);  //To don't let the computer click in my button what I take it 
            CheckGame(); //to check if we got the line of 3 botton 
            Timer.Start(); // the timer will start
        }

        private void ResetGame(object sender, EventArgs e)
        {
            RestartGame(); // to restart the game agin..
        }

        private void CheckGame()
        {
            if (button1.Text == "X" && button2.Text == "X" && button3.Text == "X"
                || button4.Text == "X" && button5.Text == "X" && button6.Text == "X"
                || button7.Text == "X" && button8.Text == "X" && button9.Text == "X"
                || button1.Text == "X" && button5.Text == "X" && button9.Text == "X"
                || button3.Text == "X" && button5.Text == "X" && button7.Text == "X"
                || button2.Text == "X" && button5.Text == "X" && button8.Text == "X"
                || button4.Text == "X" && button5.Text == "X" && button6.Text == "X")

            {
                Timer.Stop();
                MessageBox.Show("You Win !!");
                playerWinC++;
                label1.Text = "Player Win" + playerWinC;
                RestartGame();


            }
            else if (button1.Text == "O" && button2.Text == "O" && button3.Text == "O"
                || button4.Text == "O" && button5.Text == "O" && button6.Text == "O"
                || button7.Text == "O" && button8.Text == "O" && button9.Text == "O"
                || button1.Text == "O" && button5.Text == "O" && button9.Text == "O"
                || button3.Text == "O" && button5.Text == "O" && button7.Text == "O"
                || button2.Text == "O" && button5.Text == "O" && button8.Text == "O"
                || button4.Text == "O" && button5.Text == "O" && button6.Text == "O")
            {



                Timer.Stop();
                MessageBox.Show("The PC Win !!");
                computerWinC++;
                label2.Text = "PC Win" + computerWinC;
                RestartGame();
            }

            else if(bouttons.Count == 0)
                {
                    Timer.Stop(); 
                    MessageBox.Show("It's a Draw!");
                    RestartGame();
    

            }

                }

        

        private void RestartGame()
        {
            bouttons = new List<Button> { button1, button2, button3, button4, button5, button6, button7, button8, button9 };

            foreach (Button x in bouttons)
            {
                x.Enabled = true; // enable to click the button
                x.Text = string.Empty;
                x.BackColor = DefaultBackColor;

            }

        }

       
    }
}
